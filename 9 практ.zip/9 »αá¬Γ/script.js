function color()
	{
	
		let c = Math.round( 255.0 * Math.random() );
	
		return 'rgb(' + c + ', ' + c + ', ' + c + ');';
	
	}

	document.addEventListener('DOMContentLoaded', function(){
	
		let videos = document.getElementsByClassName('vidos'),
			links = document.getElementsByClassName('strelka'),
			blocks = document.getElementsByClassName('icons-s');

		links[0].onclick = function(e)
		{

			videos[0].pause();
		
			let target = e.target.parentElement.id;

			if ( target == 'set_prev_video' )
				videos[0].setAttribute('src', '111.mp4');
			else if ( target == 'set_next_video' )
				videos[0].setAttribute('src', '222.mp4');
			
			videos[0].play();
			
		}
		
		blocks[0].onclick = function(e)
		{

			if ( e.target.tagName != 'LI' )
				e.target.parentElement.setAttribute('style', 'font-size:25px;width:100%;display:block;background:' + color());
			else
				e.target.setAttribute('style', 'font-size:25px;width:100%;display:block;background:' + color());
				
			blocks[0].className = 'icons-s icons-s-new';
			
		}
	
	
		//&&
		function event__(e)
		{

			e.preventDefault();
			document.getElementById('ta_price').value = e.target.offsetParent.children[1].children[0].innerText.replace(/\$19/, '$19.');
				
		}
		
		document.onclick = function(e)
		{

			let	aaa = document.querySelectorAll('div.price');

			if ( aaa.length )
				aaa.forEach (function(e){

					e.className = 'price';
						
					let bla = e.children[2].children[0].children[0];
						
					if ( typeof(bla.addEventListener) == 'function' )
						bla.removeEventListener('click', event__, false);
						
				});

			if ( !e.target.offsetParent.className.match(/price/i) || !e.target.parentElement.parentElement.className.match(/price/i) )
				return;
			else if ( e.target.offsetParent.className.match(/price/i) )
			{
			
				e.target.offsetParent.className = 'price price_hover';
				e.target.offsetParent.children[2].children[0].children[0].addEventListener('click', event__, false);
				
			}
			else if ( e.target.parentElement.parentElement.className.match(/price/i) )
			{
			
				let bds = e.target.parentElement.parentElement;
				bds.className = 'price price_hover';
				bds.children[2].children[0].children[0].addEventListener('click', event__, false);
				
			}
		
		}
		console.log(typeof(window.opener) !== 'undefined' );
		console.log(window.opener !== null);
		/************************************/
		if ( !window.opener )
		{
			
			let iphone = document.getElementById('phone_click');
			iphone.addEventListener('click', function(e){
		
				e.preventDefault();
			
				window.open(window.location.href, "Random Block", "width=300,height=300");

		
			});
		
		}
		else
		{	
		
			let random_block = document.getElementsByClassName('price');
			
			random_block = random_block[Math.floor(Math.random() * 3 + 0)].outerHTML;
			
			window.document.body.innerHTML = random_block;
			
			let timer = setTimeout(function() {
			
				window.open('', '_self', '');
				window.close();
				
			}, 5000);
			
			document.addEventListener('click', function(){
			
				clearTimeout(timer);
			
			});
			
		}
		/************************************/
	
	});
	
	let b = document.getElementsByTagName('body'),
		g = false;
	
	document.addEventListener("input", function(e){
	
		let v = e.target.value;
		
		if ( v == '' )
		{
		
			g = false;
			
			b[0].style.fontSize = '';
			
		}
		
		if ( v.match(/lol/i) )
		{
		
			g = true;
			
			let f_size = Math.floor(Math.random() * 21) + 16;
			b[0].style.fontSize = f_size + 'px';
			
		}
	
	});
	